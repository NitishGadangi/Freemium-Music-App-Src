## Whats new ?
### (version 0.6_beta)
* Made UI Smooth by adding new animations for seamless transitions between activities.
* Added new settings tab to configure defaults.
* Added Mp3 support.
* Now you can hide AlbumArt files if needed (check settings page).
* Improved UI for Browse Page.
* Now Search Page and Browse page runs in seperate thread. So no lags anymore.
* Open downloads folders right from the app.
* New Icon designed by [Pruthvi Chandra](http://apkfolks.com).
* Now you can buy me a coffee ☕
* Fixed Several Bugs reported by many users.
* Fixed random force close issues.
* Fixed random appearance of XML code in file names.
